#!/usr/bin/env python3
"""CLI for the SLR(1) parser project.

Examples
  python main.py --show all
  python main.py --parse "let x = 5 ;" --trace
  python main.py --file examples/valid_1.src --html trace.html
  python main.py --grammar grammars/not_slr.grammar --show conflicts
  python main.py --demo
"""
import argparse
import glob
import os
import sys

from slr.grammar import Grammar, GrammarError
from slr.lr0 import Automaton
from slr.tables import SLRTable
from slr.lexer import Lexer
from slr.parser import parse_source
from slr import display as D
from slr.visualize import to_dot, trace_html

HERE = os.path.dirname(os.path.abspath(__file__))
SECTIONS = ["grammar", "first", "items", "transitions", "table", "conflicts"]


def build(path):
    g = Grammar.from_file(path)
    aut = Automaton(g)
    return g, aut, SLRTable(g, aut)


def show(g, aut, table, what):
    parts = {
        "grammar": lambda: D.grammar_text(g),
        "first": lambda: D.first_follow_text(g),
        "items": lambda: D.states_text(g, aut),
        "transitions": lambda: D.transitions_text(g, aut),
        "table": lambda: D.table_text(g, table),
        "conflicts": lambda: D.conflicts_text(g, table),
    }
    for name in (SECTIONS if what == "all" else [what]):
        print(f"\n===== {name.upper()} =====")
        print(parts[name]())


def run_one(src, g, table, lexer, trace, html, max_steps, label=None):
    res = parse_source(src, g, table, lexer, max_steps)
    if label:
        print(f"\n--- {label} ---")
    print("Input:", " ".join(src.split()) if src.strip() else "(empty)")
    if trace and res.steps:
        print(D.trace_text(res))
    if res.accepted:
        print(f"RESULT: ACCEPTED  ({len(res.steps)} steps, {len(res.reductions)} reductions)")
    else:
        print("RESULT: REJECTED")
        print(D.error_with_caret(res, src))
    if html:
        with open(html, "w", encoding="utf-8") as f:
            f.write(trace_html(g, res, src))
        print(f"Interactive trace written to {html}")
    return res


def demo(g, table, lexer, trace, max_steps):
    files = sorted(glob.glob(os.path.join(HERE, "examples", "*.src")),
                   key=lambda p: (not os.path.basename(p).startswith("valid"), os.path.basename(p)))
    summary = []
    for k, path in enumerate(files):
        name = os.path.basename(path)
        with open(path, encoding="utf-8") as f:
            src = f.read()
        res = run_one(src, g, table, lexer, trace or k == 0, None, max_steps, label=name)
        summary.append((name, "ACCEPT" if res.accepted else "REJECT"))
    print("\n===== SUMMARY =====")
    for n, r in summary:
        print(f"{n:<20} {r}")


def main(argv=None):
    ap = argparse.ArgumentParser(description="SLR(1) parser generator + parser")
    ap.add_argument("--grammar", default=os.path.join(HERE, "grammars", "minilang.grammar"))
    ap.add_argument("--show", choices=SECTIONS + ["all"], help="print grammar artefacts")
    ap.add_argument("--parse", metavar="TEXT", help="parse this source text")
    ap.add_argument("--file", metavar="PATH", help="parse this source file")
    ap.add_argument("--trace", action="store_true", help="print the step-by-step trace")
    ap.add_argument("--html", metavar="PATH", help="write an interactive HTML trace viewer")
    ap.add_argument("--dot", metavar="PATH", help="write the LR automaton as Graphviz DOT")
    ap.add_argument("--demo", action="store_true", help="run every file in examples/")
    ap.add_argument("--max-steps", type=int, default=10000)
    a = ap.parse_args(argv)

    try:
        g, aut, table = build(a.grammar)
    except (GrammarError, OSError) as e:
        print("Grammar error:", e)
        return 2

    if a.show:
        show(g, aut, table, a.show)
    if a.dot:
        with open(a.dot, "w", encoding="utf-8") as f:
            f.write(to_dot(g, aut, table))
        print(f"Automaton written to {a.dot}")

    if table.conflicts:
        if a.show not in ("conflicts", "all"):
            print("\n" + D.conflicts_text(g, table))
        if a.parse or a.file or a.demo:
            print("Parsing refused: conflicts are never resolved silently.")
        return 2

    lexer = Lexer(g)
    code = 0
    if a.parse is not None:
        code = 0 if run_one(a.parse, g, table, lexer, a.trace, a.html, a.max_steps).accepted else 1
    if a.file:
        with open(a.file, encoding="utf-8") as f:
            code = 0 if run_one(f.read(), g, table, lexer, a.trace, a.html, a.max_steps).accepted else 1
    if a.demo:
        demo(g, table, lexer, a.trace, a.max_steps)
    if not (a.show or a.parse is not None or a.file or a.demo or a.dot):
        print(D.conflicts_text(g, table))
        print(f"{len(g.productions)} productions, {len(aut.states)} states. Use --help for options.")
    return code


if __name__ == "__main__":
    sys.exit(main())
