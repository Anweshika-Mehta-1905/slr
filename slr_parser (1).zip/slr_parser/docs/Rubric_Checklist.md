# Review 2 checklist (due 14 October 2026)

## Implementation / prototype – 5 marks (75% complete)
- [x] Augmented grammar, FIRST/FOLLOW (`slr/grammar.py`)
- [x] LR(0) items, CLOSURE, GOTO, canonical collection, DFA transitions (`slr/lr0.py`)
- [x] ACTION/GOTO generated algorithmically, conflicts reported (`slr/tables.py`)
- [x] Shift-reduce parser with trace (step, stack, input, action), `$`, step limit (`slr/parser.py`)
- [x] 4 valid + 6 invalid inputs executed; 36 unit tests pass
- [ ] Planned: error recovery, parse tree, LR(1)/LALR(1) comparison

## Novelty – 2 marks
- [x] Verified expected-token errors (baseline vs contribution stated)
- [x] Interactive HTML trace viewer, DOT automaton export

## Documentation – 1 mark
- [x] `docs/Review2_Report.md` / `.docx` (fill in name, guide, Review 1 wording)
- [ ] Insert screenshots listed in report section 11

## Presentation and Q&A – 2 marks
- [x] 9-slide deck, `docs/Viva_QA.md` (16 questions)
- [ ] Rehearse the live demo: `--show table`, `--parse ... --trace`, `--demo`, HTML viewer
