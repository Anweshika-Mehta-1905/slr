# Design and Implementation of an SLR(1) Parser for a Small Programming Language
## Review 2 – Progress Report

**Student:** [name, register number]  **Guide:** [name]  **Date:** 14 October 2026

## 1. Abstract
This project implements an SLR(1) parser generator and parser in Python for MiniLang, a small language with assignments, `print`, `if/else`, `while`, arithmetic and comparisons. From a plain-text grammar file the program computes FIRST and FOLLOW sets, builds the canonical LR(0) collection (CLOSURE/GOTO), generates the ACTION/GOTO tables algorithmically, reports any shift/reduce or reduce/reduce conflict, and runs a table-driven shift-reduce parser that prints a step-by-step trace. Review 2 adds two modest features: *verified expected-token error messages* and an *interactive HTML trace viewer / automaton export*. For the MiniLang grammar the generator produced 57 states and no conflicts; 36 unit tests and 10 sample programs behave as expected.

## 2. Introduction and Motivation
Parsing is the second phase of a compiler. LR parsers handle a larger class of grammars than LL parsers, but their tables are tedious and error-prone to build by hand. Implementing the construction end to end makes the algorithms (items, closure, goto, FOLLOW-based reduction) concrete and testable. SLR(1) is the simplest LR variant that is still practical, which makes it a suitable first target.

## 3. Problem Statement and Objectives (from Review 1, condensed)
*[Replace or confirm against your Review 1 wording; the repository for Review 1 was not available when this report was prepared.]*
Design and implement an SLR(1) parser for a small programming language. Objectives: (1) choose and verify an SLR(1) grammar; (2) compute FIRST/FOLLOW; (3) construct LR(0) item sets and the DFA; (4) generate ACTION/GOTO tables without hard-coding; (5) parse with a visible stack trace; (6) detect conflicts and report syntax errors usefully.

## 4. Grammar
MiniLang (file `grammars/minilang.grammar`); ε appears in `StmtList` (empty block/program) and `Else` (optional else). Braces are mandatory, which avoids the dangling-else conflict.
```
# MiniLang: assignments, print, if/else, while, arithmetic and comparisons.
# Epsilon appears in StmtList (empty block) and Else (optional else part).
Program  -> StmtList
StmtList -> StmtList Stmt | ε
Stmt     -> let id = Expr ;
         | id = Expr ;
         | print Expr ;
         | if ( Cond ) { StmtList } Else
         | while ( Cond ) { StmtList }
Else     -> else { StmtList } | ε
Cond     -> Expr < Expr | Expr > Expr | Expr == Expr
Expr     -> Expr + Term | Expr - Term | Term
Term     -> Term * Factor | Term / Factor | Factor
Factor   -> ( Expr ) | id | num
```
The augmented grammar adds production 0, `Program' -> Program`, giving 23 productions, 20 terminals plus `$`, and 9 nonterminals (including `Program'`).

**FIRST / FOLLOW (program output):**
```
Nonterminal | FIRST | FOLLOW
------------------------------------------------
Program' | { let, id, print, if, while, ε } | { $ }
Program  | { let, id, print, if, while, ε } | { $ }
StmtList | { let, id, print, if, while, ε } | { let, id, print, if, }, while, $ }
Stmt     | { let, id, print, if, while } | { let, id, print, if, }, while, $ }
Else     | { else, ε } | { let, id, print, if, }, while, $ }
Cond     | { id, (, num } | { ) }
Expr     | { id, (, num } | { ;, ), <, >, ==, +, - }
Term     | { id, (, num } | { ;, ), <, >, ==, +, -, *, / }
Factor   | { id, (, num } | { ;, ), <, >, ==, +, -, *, / }
Nullable: Program', Program, StmtList, Else
```

## 5. Architecture
| Module | Responsibility |
|---|---|
| `slr/grammar.py` | Grammar parsing, augmentation, FIRST, FOLLOW |
| `slr/lr0.py` | Items, CLOSURE, GOTO, canonical collection, transitions |
| `slr/tables.py` | ACTION/GOTO construction, conflict detection |
| `slr/lexer.py` | Grammar-driven tokenizer with line/column |
| `slr/parser.py` | Shift-reduce driver, trace, expected tokens, step limit |
| `slr/display.py`, `slr/visualize.py` | Text output, DOT export, HTML trace viewer |
| `main.py`, `tests/test_slr.py` | CLI and unit tests |

Data flow: grammar file → FIRST/FOLLOW → LR(0) automaton → ACTION/GOTO → parser (tokens from lexer) → trace / HTML.

## 6. Algorithms
* **FIRST/FOLLOW:** fixed-point iteration over all productions until no set grows; `ε` marks nullable symbols; `FOLLOW(Program')={$}`.
* **CLOSURE(I):** repeatedly add `B -> •γ` for every item `A -> α•Bβ` in the set.
* **GOTO(I, X):** advance the dot over `X` in every item of `I` that has `X` after the dot, then take the closure.
* **Canonical collection:** start from `CLOSURE({Program' -> •Program})`, apply GOTO for every symbol after a dot, add new sets until none appear. Edges are the DFA transitions.
* **Table construction:** for item `A -> α•aβ` with `GOTO(Ii,a)=Ij`: ACTION[i,a]=shift j. For `A -> α•` (A ≠ S'): ACTION[i,a]=reduce for every `a` in FOLLOW(A). For `S' -> S•`: ACTION[i,$]=accept. GOTO[i,A]=j for `GOTO(Ii,A)=Ij`. A cell with more than one action is recorded as a conflict; the parser refuses to run on such a table.

**LR(0) item set I0 (program output):**
```
I0:
    Program' -> • Program                           [kernel]
    Program -> • StmtList                           
    StmtList -> • StmtList Stmt                     
    StmtList -> •                                   
I1:
    Program' -> Program •                           [kernel]
I2:
    Program -> StmtList •                           [kernel]
    StmtList -> StmtList • Stmt                     [kernel]
    Stmt -> • let id = Expr ;                       
    Stmt -> • id = Expr ;                           
    Stmt -> • print Expr ;                          
    Stmt -> • if ( Cond ) { StmtList } Else         
    Stmt -> • while ( Cond ) { StmtList }
```
**Table excerpt (states 0–12, first column group only: ACTION plus the Program/StmtList/Stmt GOTO columns; the full 57-state table with the remaining GOTO columns is in `docs/evidence/01_all_artifacts.txt`):**
```

      |ACTION                                                                                     GOTO                  
state |let id  =   ;   print if  (   )   {   }   while else <   >   ==  +   -   *   /   num $   Program StmtList Stmt 
----------------------------------------------------------------------------------------------------------------------
0     |r3  r3          r3    r3              r3  r3                                         r3  1       2             
1     |                                                                                     acc                       
2     |s4  s5          s6    s7                  s8                                         r1                   3    
3     |r2  r2          r2    r2              r2  r2                                         r2                        
4     |    s9                                                                                                         
5     |        s10                                                                                                    
6     |    s15                   s14                                                    s16                           
7     |                          s17                                                                                  
8     |                          s18                                                                                  
9     |        s19                                                                                                    
10    |    s15                   s14                                                    s16                           
11    |            s21                                                  s22 s23                                       
12    |            r16               r16                    r16 r16 r16 r16 r16 s24 s25                               
```
Result: 57 states, 147 transitions, 102 shift, 163 reduce and 1 accept entries, 45 GOTO entries, **0 conflicts**.

## 7. Parsing
The driver keeps a stack of states and symbols. Per step it looks up ACTION[top, lookahead]: *shift* pushes the token and state; *reduce A -> α* pops |α| symbols and states, pushes A and GOTO[top, A]; *accept* ends; an empty cell is a syntax error. A step limit (default 10 000) stops runaway loops. Representative trace, input `let x = 1 + 2 ;` (actual output):
```
Input: let x = 1 + 2 ;
Step | Stack (state/symbol)                                | Remaining input        | Action                          
-----+-----------------------------------------------------+------------------------+---------------------------------
1    | 0                                                   | let id = num + num ; $ | Reduce StmtList -> ε            
2    | 0 StmtList 2                                        | let id = num + num ; $ | Shift 4                         
3    | 0 StmtList 2 let 4                                  | id = num + num ; $     | Shift 9                         
4    | 0 StmtList 2 let 4 id 9                             | = num + num ; $        | Shift 19                        
5    | 0 StmtList 2 let 4 id 9 = 19                        | num + num ; $          | Shift 16                        
6    | 0 StmtList 2 let 4 id 9 = 19 num 16                 | + num ; $              | Reduce Factor -> num            
7    | 0 StmtList 2 let 4 id 9 = 19 Factor 13              | + num ; $              | Reduce Term -> Factor           
8    | 0 StmtList 2 let 4 id 9 = 19 Term 12                | + num ; $              | Reduce Expr -> Term             
9    | 0 StmtList 2 let 4 id 9 = 19 Expr 30                | + num ; $              | Shift 22                        
10   | 0 StmtList 2 let 4 id 9 = 19 Expr 30 + 22           | num ; $                | Shift 16                        
11   | 0 StmtList 2 let 4 id 9 = 19 Expr 30 + 22 num 16    | ; $                    | Reduce Factor -> num            
12   | 0 StmtList 2 let 4 id 9 = 19 Expr 30 + 22 Factor 13 | ; $                    | Reduce Term -> Factor           
13   | 0 StmtList 2 let 4 id 9 = 19 Expr 30 + 22 Term 32   | ; $                    | Reduce Expr -> Expr + Term      
14   | 0 StmtList 2 let 4 id 9 = 19 Expr 30                | ; $                    | Shift 42                        
15   | 0 StmtList 2 let 4 id 9 = 19 Expr 30 ; 42           | $                      | Reduce Stmt -> let id = Expr ;  
16   | 0 StmtList 2 Stmt 3                                 | $                      | Reduce StmtList -> StmtList Stmt
17   | 0 StmtList 2                                        | $                      | Reduce Program -> StmtList      
18   | 0 Program 1                                         | $                      | Accept                          
RESULT: ACCEPTED  (18 steps, 10 reductions)
```
Cross-check with the textbook grammar (Dragon Book, `id + id * id`): the program produces the expected 8 reductions in the correct order and the 12-state automaton the textbook describes (`docs/evidence/08_trace_classic.txt`); compare the state numbers with your edition of the book before quoting them.

## 8. Novelty (2 marks)
**Baseline:** textbook SLR construction and a parser that reports "syntax error" at the failing token. **Contribution (modest, engineering-level):**
1. **Verified expected-token messages.** An SLR state reduces on every token in FOLLOW, so the raw ACTION row over-reports what may follow. For each candidate token the program dry-runs the reductions on a copy of the stack and keeps it only if a shift/accept is reached. Example: for `print x` at end of input the raw row also contains `)`, `<`, `>`, `==`, but the message lists only `;`, `+`, `-`, `*`, `/`. A unit test checks this.
2. **Interactive trace viewer and automaton export.** `--html` writes a self-contained page with Prev/Next/Play, a stack drawn as boxes, popped symbols highlighted on reductions, and the input with the next token marked. `--dot` exports the 57-state DFA for Graphviz.

No claim is made that these are research-level novelties; they are usability features built on the standard algorithm.

## 9. Implementation Status
| Item | Status |
|---|---|
| Augmented grammar, FIRST/FOLLOW, items, CLOSURE/GOTO, DFA | Completed, tested |
| ACTION/GOTO generation and conflict detection | Completed, tested |
| Shift-reduce parser, trace, step limit | Completed, tested |
| Lexer with line/column, lexical errors | Completed, tested |
| Expected-token errors, HTML viewer, DOT export | Completed |
| Panic-mode error recovery, parse tree/AST, semantic actions | Planned |
| Comparison with LR(1)/LALR(1) | Planned |

## 10. Tests and Results (actual execution)
Unit tests: `python -m unittest discover -s tests -v` → `Ran 36 tests in 0.022s`, `OK` (36 tests across FIRST/FOLLOW, CLOSURE/GOTO, transitions, table generation, conflict detection, acceptance, rejection, end-of-input, reduction correctness, step limit, lexer).

| Input | Expected | Result |
|---|---|---|
| `valid_1.src` (let, print, arithmetic) | accept | accepted (50 steps) |
| `valid_2.src` (while) | accept | accepted (53 steps) |
| `valid_3.src` (if/else) | accept | accepted (57 steps) |
| empty program | accept | accepted (3 steps) |
| `let x = ;` | reject | rejected, expected identifier, `(`, number |
| `if ( x < 5 ) { print x ;` | reject | rejected at end of input, `}` among expected |
| `x = 3 + * 4 ;` | reject | rejected at `*` |
| `print x` | reject | rejected, expected `;`, `+`, `-`, `*`, `/` |
| `let y = 3 @ 4 ;` | reject | lexical error, line 1 column 11 |
| `while ( x ) { print x ; }` | reject | rejected at `)` |

Error messages (actual output):
```

```
Conflict detection on non-SLR grammars (`docs/evidence/06_conflict_detection.txt`): the classic `S -> L = R | R` grammar gives a shift/reduce conflict on `=`; the ambiguous `E -> E+E | E*E | id` gives 4; dangling else gives 1; `S -> A | B, A -> x, B -> x` gives a reduce/reduce conflict on `$`. In every case parsing is refused.

## 11. Evidence to Capture (screenshots)
1. Terminal: `python main.py --show all` (grammar, FIRST/FOLLOW, item sets, table).
2. Terminal: `python main.py --parse "let x = 1 + 2 ;" --trace`.
3. Terminal: `python main.py --demo` summary (valid/invalid).
4. Terminal: `python -m unittest discover -s tests -v` showing `OK`.
5. Terminal: conflict report for `grammars/not_slr.grammar`.
6. Browser: `docs/evidence/trace_short.html` mid-reduction, and `trace_error.html` at the error step.
7. Image: `docs/evidence/classic_automaton.png` (12 states).
Ready-made captures from this run: `docs/evidence/screenshot_*.png`.

## 12. Limitations
* SLR(1) is weaker than LALR(1)/LR(1): some unambiguous grammars (e.g. the classic `S -> L = R` grammar) give false conflicts.
* Stops at the first syntax error; no recovery.
* No parse tree, AST, type checking or code generation.
* The lexer supports only integers, identifiers, keywords and operators; no comments, strings or floats.
* Braces are mandatory in `if`/`while`; a dangling-else form would need a different grammar or precedence rules, which the tool deliberately does not apply silently.

## 13. Future Work
Panic-mode recovery with synchronising tokens; building a parse tree/AST via semantic actions; LR(1) and LALR(1) construction to compare state counts; more extensive tests, including generated random programs.

## 14. Conclusion
The core SLR(1) pipeline is complete, runs end to end from a grammar file, and has been checked against a textbook grammar and 36 automated tests. The two added features make errors and traces easier to understand. The remaining work is optional extension beyond the Review 2 prototype.

## 15. References
1. A. V. Aho, M. S. Lam, R. Sethi, J. D. Ullman, *Compilers: Principles, Techniques, and Tools*, 2nd ed., Pearson, 2007 (Chapter 4).
2. K. D. Cooper, L. Torczon, *Engineering a Compiler*, 2nd ed., Morgan Kaufmann, 2011.
3. D. Grune, K. van Reeuwijk, H. E. Bal, C. J. H. Jacobs, K. Langendoen, *Modern Compiler Design*, 2nd ed., Springer, 2012.
4. F. DeRemer, "Simple LR(k) grammars", *Communications of the ACM* 14(7), 1971.
