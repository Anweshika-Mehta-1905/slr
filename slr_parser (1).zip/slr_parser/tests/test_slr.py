"""Unit tests (stdlib unittest).  Run:  python -m unittest discover -s tests -v"""
import os
import sys
import unittest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from slr.grammar import Grammar, EPSILON, END, GrammarError
from slr.lr0 import Automaton, closure, goto
from slr.tables import SLRTable
from slr.lexer import Lexer, LexError
from slr.parser import parse, parse_source

GDIR = os.path.join(os.path.dirname(__file__), "..", "grammars")


def build(name):
    g = Grammar.from_file(os.path.join(GDIR, name))
    aut = Automaton(g)
    return g, aut, SLRTable(g, aut)


def prod_index(g, text):
    return next(p.index for p in g.productions if str(p) == text)


class FirstFollow(unittest.TestCase):
    def test_classic_first_follow(self):
        g, _, _ = build("classic_expr.grammar")
        for nt in "ETF":
            self.assertEqual(g.first[nt], {"(", "id"})
        self.assertEqual(g.follow["E"], {"+", ")", END})
        self.assertEqual(g.follow["T"], {"+", "*", ")", END})
        self.assertEqual(g.follow["F"], {"+", "*", ")", END})

    def test_epsilon(self):
        g = Grammar.from_text("S -> A b\nA -> a | ε")
        self.assertEqual(g.first["A"], {"a", EPSILON})
        self.assertEqual(g.first["S"], {"a", "b"})
        self.assertEqual(g.follow["A"], {"b"})

    def test_nullable_chain_follow(self):
        g = Grammar.from_text("S -> A B\nA -> a | ε\nB -> b | ε")
        self.assertEqual(g.first["S"], {"a", "b", EPSILON})
        self.assertEqual(g.follow["A"], {"b", END})
        self.assertEqual(g.follow["B"], {END})

    def test_augmentation(self):
        g, _, _ = build("classic_expr.grammar")
        self.assertEqual(str(g.productions[0]), "E' -> E")
        self.assertEqual(g.follow["E'"], {END})

    def test_bad_grammar_text(self):
        with self.assertRaises(GrammarError):
            Grammar.from_text("S -> a |")


class ClosureGoto(unittest.TestCase):
    def setUp(self):
        self.g, self.aut, _ = build("classic_expr.grammar")

    def test_closure_of_start(self):
        i0 = closure(self.g, {(0, 0)})
        self.assertEqual(len(i0), 7)   # E'->.E, E->.E+T, E->.T, T->.T*F, T->.F, F->.(E), F->.id

    def test_goto_on_E(self):
        i0 = closure(self.g, {(0, 0)})
        j = goto(self.g, i0, "E")
        self.assertEqual({(self.g.productions[p].lhs, d) for p, d in j}, {("E'", 1), ("E", 1)})

    def test_goto_on_missing_symbol_is_empty(self):
        i0 = closure(self.g, {(0, 0)})
        self.assertEqual(goto(self.g, i0, "+"), frozenset())

    def test_state_count_matches_textbook(self):
        self.assertEqual(len(self.aut.states), 12)

    def test_transitions_deterministic_and_consistent(self):
        for (i, x), j in self.aut.transitions.items():
            self.assertEqual(self.aut.states[j], goto(self.g, self.aut.states[i], x))

    def test_kernel_items(self):
        for i in range(len(self.aut.states)):
            for p, d in self.aut.kernel(i):
                self.assertTrue(d > 0 or p == 0)


class TableAndConflicts(unittest.TestCase):
    def test_classic_is_slr1(self):
        _, _, t = build("classic_expr.grammar")
        self.assertTrue(t.is_slr1)

    def test_accept_entry(self):
        g, aut, t = build("classic_expr.grammar")
        s1 = aut.transitions[(0, "E")]
        self.assertEqual(t.action[s1][END], [("acc",)])

    def test_shift_and_goto_entries(self):
        g, aut, t = build("classic_expr.grammar")
        self.assertEqual(t.action[0]["id"], [("s", aut.transitions[(0, "id")])])
        self.assertEqual(t.goto[0]["E"], aut.transitions[(0, "E")])

    def test_reduce_only_on_follow(self):
        g, aut, t = build("minilang.grammar")
        for i, row in t.action.items():
            for a, cell in row.items():
                for act in cell:
                    if act[0] == "r":
                        self.assertIn(a, g.follow[g.productions[act[1]].lhs])

    def test_not_slr_grammar_detected(self):
        g, _, t = build("not_slr.grammar")
        self.assertFalse(t.is_slr1)
        c = [c for c in t.conflicts if c.symbol == "="]
        self.assertTrue(c and c[0].kind == "shift/reduce")

    def test_ambiguous_grammar_detected(self):
        _, _, t = build("ambiguous.grammar")
        self.assertTrue(any(c.kind == "shift/reduce" for c in t.conflicts))

    def test_dangling_else_detected(self):
        _, _, t = build("dangling_else.grammar")
        self.assertTrue(any(c.symbol == "else" for c in t.conflicts))

    def test_reduce_reduce_detected(self):
        _, _, t = build("reduce_reduce.grammar")
        self.assertTrue(any(c.kind == "reduce/reduce" and c.symbol == END for c in t.conflicts))

    def test_parser_refuses_conflicting_table(self):
        g, _, t = build("ambiguous.grammar")
        with self.assertRaises(ValueError):
            parse(Lexer(g).tokenize("id + id"), g, t)

    def test_minilang_is_slr1(self):
        _, _, t = build("minilang.grammar")
        self.assertTrue(t.is_slr1)


class Parsing(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.g, cls.aut, cls.t = build("minilang.grammar")
        cls.lx = Lexer(cls.g)

    def run_src(self, src, **kw):
        return parse_source(src, self.g, self.t, self.lx, **kw)

    def test_valid_programs(self):
        for src in ["let x = 1 ;", "x = ( 1 + 2 ) * 3 ;", "print a - b / 2 ;",
                    "while ( a < 3 ) { a = a + 1 ; }",
                    "if ( a == 1 ) { } else { print a ; }",
                    "if ( a > 1 ) { print a ; }",
                    "if ( a > 1 ) { if ( b < 2 ) { print b ; } else { } } else { x = 1 ; }",
                    ""]:
            with self.subTest(src=src):
                self.assertTrue(self.run_src(src).accepted)

    def test_invalid_programs(self):
        for src in ["let x = ;", "x = 3 + * 4 ;", "print x", "if ( x < 5 ) { print x ;",
                    "while ( x ) { }", "let = 5 ;", "x = 1 ; ;", "else { }", "x = ( 1 + 2 ;",
                    "x = 1 2 ;"]:
            with self.subTest(src=src):
                self.assertFalse(self.run_src(src).accepted)

    def test_lexical_error(self):
        r = self.run_src("x = 3 @ 4 ;")
        self.assertFalse(r.accepted)
        self.assertEqual(r.error.kind, "lexical")
        self.assertEqual((r.error.line, r.error.col), (1, 7))

    def test_end_of_input_handling(self):
        r = self.run_src("print x")
        self.assertFalse(r.accepted)
        self.assertEqual(r.error.token.type, END)
        self.assertIn("end of input", r.error.message)
        self.assertEqual(r.steps[-1].remaining, [END])

    def test_missing_end_marker_never_accepts(self):
        # a token list without '$' must not be accepted silently
        toks = self.lx.tokenize("let x = 1 ;")[:-1]
        with self.assertRaises(IndexError):
            parse(toks, self.g, self.t)

    def test_expected_tokens_after_assign(self):
        r = self.run_src("let x = ;")
        self.assertEqual(set(r.error.expected), {"id", "num", "("})
        self.assertEqual((r.error.line, r.error.col), (1, 9))

    def test_expected_tokens_are_verified(self):
        # After 'print x' the state is  Factor -> id .  which reduces on ALL of FOLLOW(Factor),
        # so the raw ACTION row contains ')' and '<' that can never follow here.
        r = self.run_src("print x")
        self.assertIn(")", r.error.expected_raw)
        self.assertIn("<", r.error.expected_raw)
        self.assertEqual(set(r.error.expected), {";", "+", "-", "*", "/"})

    def test_expected_tokens_inside_block(self):
        r = self.run_src("if ( x < 5 ) { print x ;")
        self.assertIn("}", r.error.expected)
        self.assertNotIn(END, r.error.expected)

    def test_acceptance_final_configuration(self):
        r = self.run_src("let x = 1 ;")
        last = r.steps[-1]
        self.assertEqual(last.kind, "accept")
        self.assertEqual(last.remaining, [END])
        self.assertEqual(last.symbols, ["Program"])

    def test_reduction_pops_exactly_rhs(self):
        r = self.run_src("let x = ( 1 + 2 ) * y ; if ( x < 3 ) { print x ; } else { }")
        self.assertTrue(r.accepted)
        n_red = 0
        for s in r.steps:
            if s.kind == "reduce":
                n_red += 1
                self.assertEqual(tuple(s.popped), self.g.productions[s.prod].rhs)
                self.assertEqual(len(s.states) - 1, len(s.symbols))
        self.assertEqual(n_red, len(r.reductions))

    def test_reductions_form_rightmost_derivation(self):
        # Replay reductions in reverse: each replaces the rightmost nonterminal -> input tokens
        src = "let x = 1 + 2 * 3 ; while ( x > 0 ) { x = x - 1 ; }"
        r = self.run_src(src)
        self.assertTrue(r.accepted)
        form = [self.g.start]
        for pidx in reversed(r.reductions):
            prod = self.g.productions[pidx]
            k = max(i for i, s in enumerate(form) if s == prod.lhs)   # rightmost occurrence
            form[k:k + 1] = list(prod.rhs)
        self.assertEqual(form, [t.type for t in r.tokens[:-1]])

    def test_classic_trace_matches_textbook(self):
        g, aut, t = build("classic_expr.grammar")
        r = parse(Lexer(g).tokenize("id + id * id"), g, t)
        self.assertTrue(r.accepted)
        names = [str(g.productions[p]) for p in r.reductions]
        self.assertEqual(names, ["F -> id", "T -> F", "E -> T", "F -> id", "T -> F",
                                 "F -> id", "T -> T * F", "E -> E + T"])

    def test_step_limit(self):
        r = self.run_src("let x = 1 ;", max_steps=3)
        self.assertFalse(r.accepted)
        self.assertEqual(r.error.kind, "limit")
        self.assertEqual(len(r.steps), 3)


class LexerTests(unittest.TestCase):
    def test_longest_match_and_keywords(self):
        g, _, _ = build("minilang.grammar")
        types = [t.type for t in Lexer(g).tokenize("if a==b printer")]
        self.assertEqual(types, ["if", "id", "==", "id", "id", "$"])

    def test_unknown_char(self):
        g, _, _ = build("minilang.grammar")
        with self.assertRaises(LexError):
            Lexer(g).tokenize("x = 1 # 2")


if __name__ == "__main__":
    unittest.main()
