"""Plain-text rendering of every artefact (grammar, FIRST/FOLLOW, item sets, tables, trace)."""
from .grammar import EPSILON, END


def fmt_set(g, s):
    return "{ " + ", ".join(g.sort_syms(s)) + " }"


def grammar_text(g):
    lines = ["Augmented grammar (production numbers are used by reduce actions):"]
    for p in g.productions:
        lines.append(f"  [{p.index:>2}] {p}")
    lines.append(f"Terminals    : {' '.join(g.terminals)} {END}")
    lines.append(f"Nonterminals : {' '.join(g.nonterminals)}")
    return "\n".join(lines)


def first_follow_text(g):
    w = max(len(nt) for nt in g.nonterminals)
    out = [f"{'Nonterminal':<{w}} | FIRST | FOLLOW", "-" * (w + 40)]
    for nt in g.nonterminals:
        out.append(f"{nt:<{w}} | {fmt_set(g, g.first[nt])} | {fmt_set(g, g.follow[nt])}")
    nullable = [nt for nt in g.nonterminals if EPSILON in g.first[nt]]
    out.append(f"Nullable: {', '.join(nullable) if nullable else '(none)'}")
    return "\n".join(out)


def item_str(g, item):
    p, d = item
    prod = g.productions[p]
    rhs = list(prod.rhs)
    rhs.insert(d, "•")
    return f"{prod.lhs} -> {' '.join(rhs)}"


def states_text(g, aut):
    out = [f"Canonical LR(0) collection: {len(aut.states)} states"]
    for i, items in enumerate(aut.states):
        out.append(f"I{i}:")
        kern = aut.kernel(i)
        for it in sorted(items):
            out.append(f"    {item_str(g, it):<48}{'[kernel]' if it in kern else ''}")
    return "\n".join(out)


def transitions_text(g, aut):
    out = [f"DFA transitions ({len(aut.transitions)} edges):"]
    for (i, x), j in sorted(aut.transitions.items(), key=lambda kv: (kv[0][0], g.symbols.index(kv[0][1]))):
        out.append(f"    I{i} --{x}--> I{j}")
    return "\n".join(out)


def table_text(g, table, width=118):
    cols = [("ACTION", t) for t in g.terminals + [END]] + [("GOTO", n) for n in g.nonterminals[1:]]
    cells = {}
    for i in range(len(table.automaton.states)):
        for sec, s in cols:
            cells[(i, s)] = (table.cell_str(i, s) if sec == "ACTION"
                             else (str(table.goto[i][s]) if s in table.goto[i] else ""))
    wid = {s: max(len(s), 3, *(len(cells[(i, s)]) for i in range(len(table.automaton.states)))) + 1
           for _, s in cols}
    chunks, cur, used = [], [], 7
    for c in cols:
        if cur and used + wid[c[1]] > width:
            chunks.append(cur)
            cur, used = [], 7
        cur.append(c)
        used += wid[c[1]]
    chunks.append(cur)
    out = ["SLR(1) parsing table (sNN = shift to state NN, rNN = reduce by production NN, acc = accept):"]
    for chunk in chunks:
        head1, last = f"{'':<6}|", None
        for sec, s in chunk:
            head1 += f"{(sec if sec != last else ''):<{wid[s]}}"
            last = sec
        head2 = f"{'state':<6}|" + "".join(f"{s:<{wid[s]}}" for _, s in chunk)
        out += ["", head1, head2, "-" * len(head2)]
        for i in range(len(table.automaton.states)):
            out.append(f"{i:<6}|" + "".join(f"{cells[(i, s)]:<{wid[s]}}" for _, s in chunk))
    return "\n".join(out)


def conflicts_text(g, table):
    if not table.conflicts:
        return "Conflict check: no conflicts - the grammar is SLR(1)."
    out = [f"Conflict check: {len(table.conflicts)} conflict(s) - the grammar is NOT SLR(1):"]
    out += ["    " + c.describe(g) for c in table.conflicts]
    return "\n".join(out)


def trace_text(result):
    rows = [(str(s.n), s.stack_str(), s.remaining_str(), s.action) for s in result.steps]
    hdr = ("Step", "Stack (state/symbol)", "Remaining input", "Action")
    w = [max(len(hdr[k]), *(len(r[k]) for r in rows)) for k in range(4)] if rows else [len(h) for h in hdr]
    line = lambda r: " | ".join(f"{r[k]:<{w[k]}}" for k in range(4))
    out = [line(hdr), "-+-".join("-" * x for x in w)] + [line(r) for r in rows]
    return "\n".join(out)


def error_with_caret(result, source):
    e = result.error
    out = [e.message]
    if e.line is not None and source:
        lines = source.splitlines() or [""]
        if 1 <= e.line <= len(lines):
            out += ["    " + lines[e.line - 1], "    " + " " * (e.col - 1) + "^"]
    return "\n".join(out)
