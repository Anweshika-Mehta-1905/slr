"""Grammar representation, augmentation, FIRST and FOLLOW sets."""

EPSILON = "ε"
END = "$"
_EPS_ALIASES = {"ε", "ϵ", "eps", "epsilon", "λ"}


class GrammarError(Exception):
    pass


class Production:
    def __init__(self, index, lhs, rhs):
        self.index = index
        self.lhs = lhs
        self.rhs = tuple(rhs)

    def __str__(self):
        return f"{self.lhs} -> {' '.join(self.rhs) if self.rhs else EPSILON}"

    __repr__ = __str__


class Grammar:
    """Context-free grammar. Production 0 is the augmented rule S' -> S."""

    def __init__(self, rules, start=None):
        if not rules:
            raise GrammarError("grammar has no productions")
        user_nts = []
        for lhs, _ in rules:
            if lhs not in user_nts:
                user_nts.append(lhs)
        self.start = start or rules[0][0]
        if self.start not in user_nts:
            raise GrammarError(f"start symbol '{self.start}' has no productions")

        aug = self.start + "'"
        while aug in user_nts:
            aug += "'"
        self.aug_start = aug
        self.productions = [Production(0, aug, (self.start,))]
        for i, (lhs, rhs) in enumerate(rules, 1):
            self.productions.append(Production(i, lhs, rhs))

        self.nonterminals = [aug] + user_nts
        self.nt_set = set(self.nonterminals)
        self.terminals = []
        for p in self.productions:
            for s in p.rhs:
                if s not in self.nt_set and s not in self.terminals:
                    self.terminals.append(s)
        if END in self.terminals:
            raise GrammarError("'$' is reserved for end-of-input")
        self.by_lhs = {nt: [p for p in self.productions if p.lhs == nt]
                       for nt in self.nonterminals}
        self.symbols = self.nonterminals[1:] + self.terminals

        self.first = {}
        self.follow = {}
        self._compute_first()
        self._compute_follow()

    # ---------- construction from text ----------
    @classmethod
    def from_text(cls, text):
        rules, cur = [], None
        for ln, raw in enumerate(text.splitlines(), 1):
            line = raw.split("#", 1)[0].strip()
            if not line:
                continue
            if line.startswith("|"):
                if cur is None:
                    raise GrammarError(f"line {ln}: '|' before any rule")
                body = line[1:]
            elif "->" in line:
                lhs, body = line.split("->", 1)
                cur = lhs.strip()
                if not cur or len(cur.split()) != 1:
                    raise GrammarError(f"line {ln}: bad left-hand side")
            else:
                raise GrammarError(f"line {ln}: expected 'A -> ...' or '| ...'")
            for alt in body.split("|"):
                syms = alt.split()
                if not syms:
                    raise GrammarError(f"line {ln}: empty alternative; write ε explicitly")
                if len(syms) == 1 and syms[0] in _EPS_ALIASES:
                    syms = []
                rules.append((cur, tuple(syms)))
        return cls(rules)

    @classmethod
    def from_file(cls, path):
        with open(path, encoding="utf-8") as f:
            return cls.from_text(f.read())

    # ---------- helpers ----------
    def is_nonterminal(self, s):
        return s in self.nt_set

    def sort_syms(self, syms):
        def key(s):
            if s == END:
                return len(self.terminals) + 1
            if s == EPSILON:
                return len(self.terminals)
            return self.terminals.index(s) if s in self.terminals else -1
        return sorted(syms, key=key)

    # ---------- FIRST ----------
    def first_of_seq(self, seq):
        result = set()
        for s in seq:
            f = self.first[s]
            result |= f - {EPSILON}
            if EPSILON not in f:
                return result
        result.add(EPSILON)
        return result

    def _compute_first(self):
        self.first = {t: {t} for t in self.terminals}
        for nt in self.nonterminals:
            self.first[nt] = set()
        changed = True
        while changed:
            changed = False
            for p in self.productions:
                f = self.first_of_seq(p.rhs)
                if not f <= self.first[p.lhs]:
                    self.first[p.lhs] |= f
                    changed = True

    # ---------- FOLLOW ----------
    def _compute_follow(self):
        self.follow = {nt: set() for nt in self.nonterminals}
        self.follow[self.aug_start].add(END)
        changed = True
        while changed:
            changed = False
            for p in self.productions:
                for i, b in enumerate(p.rhs):
                    if b not in self.nt_set:
                        continue
                    f = self.first_of_seq(p.rhs[i + 1:])
                    add = f - {EPSILON}
                    if EPSILON in f:
                        add |= self.follow[p.lhs]
                    if not add <= self.follow[b]:
                        self.follow[b] |= add
                        changed = True
