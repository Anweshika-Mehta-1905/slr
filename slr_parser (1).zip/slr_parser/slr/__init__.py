"""SLR(1) parser generator and parser for a small language (educational project)."""
