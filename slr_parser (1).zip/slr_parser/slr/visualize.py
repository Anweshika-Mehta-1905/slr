"""NOVELTY: LR automaton export (Graphviz DOT) and a self-contained interactive trace viewer (HTML)."""
import json
from .display import item_str


def to_dot(g, aut, table):
    def esc(s):
        return s.replace("\\", "\\\\").replace('"', '\\"')
    out = ["digraph SLR {", "  rankdir=LR;", '  node [shape=box, fontname="Courier", fontsize=10];']
    for i, items in enumerate(aut.states):
        kern = aut.kernel(i)
        lines = [f"I{i}"] + [("* " if it in kern else "  ") + item_str(g, it) for it in sorted(items)]
        extra = ""
        if any(a[0] == "acc" for c in table.action[i].values() for a in c):
            extra = ", style=bold, color=darkgreen"
        elif any(a[0] == "r" for c in table.action[i].values() for a in c):
            extra = ", peripheries=2"
        label = "\\l".join(esc(l) for l in lines) + "\\l"
        out.append(f'  I{i} [label="{label}"{extra}];')
    for (i, x), j in sorted(aut.transitions.items()):
        out.append(f'  I{i} -> I{j} [label="{esc(x)}"];')
    out.append("}")
    return "\n".join(out)


def trace_html(g, result, source, title="SLR parse trace"):
    steps = [dict(n=s.n, states=s.states, symbols=s.symbols, remaining=s.remaining,
                  action=s.action, kind=s.kind, popped=len(s.popped),
                  prod=(str(g.productions[s.prod]) if s.prod is not None else None))
             for s in result.steps]
    data = dict(title=title, source=source, accepted=result.accepted, steps=steps,
                error=(dict(message=result.error.message, expected=result.error.expected)
                       if result.error else None))
    return _HTML.replace("__DATA__", json.dumps(data).replace("</", "<\\/"))


_HTML = r"""<!doctype html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1"><title>SLR parse trace</title>
<style>
:root{--bg:#fff;--fg:#1c1c1e;--mut:#6b6b70;--card:#f3f3f6;--bd:#d0d0d8;--sh:#d6e9ff;--rd:#ffe3b8;--ac:#cdf0d2;--er:#ffd0d0;--hl:#fff3a8}
@media(prefers-color-scheme:dark){:root{--bg:#18181b;--fg:#ececf0;--mut:#9a9aa3;--card:#25252b;--bd:#3a3a44;--sh:#1e3a5c;--rd:#5c4116;--ac:#1c4a28;--er:#5c2020;--hl:#5a5314}}
body{font-family:system-ui,sans-serif;background:var(--bg);color:var(--fg);margin:0;padding:16px;max-width:1000px;margin-inline:auto}
h1{font-size:20px;margin:0 0 4px}.mut{color:var(--mut);font-size:13px}
.card{background:var(--card);border:1px solid var(--bd);border-radius:8px;padding:12px;margin:12px 0}
.stack{display:flex;gap:4px;flex-wrap:wrap;align-items:center;min-height:44px}
.cell{border:1px solid var(--bd);border-radius:5px;padding:6px 9px;font-family:ui-monospace,monospace;background:var(--bg)}
.cell.st{color:var(--mut)}.cell.pop{background:var(--rd);border-color:#c88}
.chip{display:inline-block;border:1px solid var(--bd);border-radius:12px;padding:3px 9px;margin:2px;font-family:ui-monospace,monospace;background:var(--bg)}
.chip.next{background:var(--sh);font-weight:600}
button{padding:6px 12px;border:1px solid var(--bd);border-radius:6px;background:var(--bg);color:var(--fg);cursor:pointer}
input[type=range]{width:100%}
#act{font-family:ui-monospace,monospace;padding:8px;border-radius:6px}
.shift{background:var(--sh)}.reduce{background:var(--rd)}.accept{background:var(--ac)}.error{background:var(--er)}
table{border-collapse:collapse;width:100%;font-size:13px;font-family:ui-monospace,monospace}
td,th{border-bottom:1px solid var(--bd);padding:3px 6px;text-align:left}tr.cur{background:var(--hl)}tr{cursor:pointer}
</style></head><body>
<h1 id="t"></h1><div class="mut" id="src"></div>
<div class="card"><div class="mut">Stack (state, symbol, state, ...) - bottom on the left</div><div class="stack" id="stack"></div></div>
<div class="card"><div class="mut">Remaining input (next token highlighted)</div><div id="inp"></div></div>
<div class="card"><div class="mut">Action at this step</div><div id="act"></div><div class="mut" id="msg" style="margin-top:6px"></div></div>
<div><button id="prev">&larr; Prev</button> <button id="next">Next &rarr;</button> <button id="play">Play</button>
<span class="mut" id="pos"></span><input id="sl" type="range" min="0" value="0"></div>
<div class="card" id="tw" style="max-height:260px;overflow:auto"><table id="tbl"><thead><tr><th>Step</th><th>Stack</th><th>Remaining</th><th>Action</th></tr></thead><tbody></tbody></table></div>
<script>
const D=__DATA__;let i=0,timer=null;
const $=id=>document.getElementById(id);
const stackStr=s=>{let p=[s.states[0]];s.symbols.forEach((x,k)=>p.push(x,s.states[k+1]));return p.join(' ')};
$('t').textContent=D.title;$('src').textContent='Input: '+D.source.replace(/\s+/g,' ');
const sl=$('sl');sl.max=D.steps.length-1;
const tb=$('tbl').querySelector('tbody');
D.steps.forEach((s,k)=>{const r=tb.insertRow();[s.n,stackStr(s),s.remaining.join(' '),s.action].forEach(v=>r.insertCell().textContent=v);r.onclick=()=>{i=k;draw()}});
function draw(){const s=D.steps[i];
 const st=$('stack');st.innerHTML='';
 const total=s.states.length+s.symbols.length;let idx=0;
 const mk=(t,c)=>{const e=document.createElement('span');e.className='cell '+c;e.textContent=t;st.appendChild(e);return e};
 const cells=[mk(s.states[0],'st')];
 s.symbols.forEach((x,k)=>{cells.push(mk(x,''));cells.push(mk(s.states[k+1],'st'))});
 if(s.kind==='reduce'&&s.popped>0)cells.slice(cells.length-2*s.popped).forEach(c=>c.classList.add('pop'));
 const inp=$('inp');inp.innerHTML='';
 s.remaining.forEach((t,k)=>{const e=document.createElement('span');e.className='chip'+(k===0?' next':'');e.textContent=t;inp.appendChild(e)});
 const a=$('act');a.textContent=s.action;a.className=s.kind;
 let m='';if(s.kind==='reduce')m='Pop '+s.popped+' symbol(s) (highlighted) and their states, push the left-hand side, then take GOTO.';
 if(s.kind==='shift')m='Push the lookahead token and the new state; advance the input.';
 if(s.kind==='accept')m='Input accepted.';
 if(s.kind==='error'&&D.error)m=D.error.message;
 $('msg').textContent=m;$('pos').textContent=' step '+s.n+' of '+D.steps.length+' ';sl.value=i;
 [...tb.rows].forEach((r,k)=>r.className=k===i?'cur':'');
 const r=tb.rows[i],w=$('tw');w.scrollTop=r.offsetTop-w.clientHeight/2}
const go=d=>{i=Math.max(0,Math.min(D.steps.length-1,i+d));draw()};
$('prev').onclick=()=>go(-1);$('next').onclick=()=>go(1);sl.oninput=()=>{i=+sl.value;draw()};
$('play').onclick=()=>{if(timer){clearInterval(timer);timer=null;$('play').textContent='Play';return}
 $('play').textContent='Pause';timer=setInterval(()=>{if(i>=D.steps.length-1){clearInterval(timer);timer=null;$('play').textContent='Play'}else go(1)},700)};
document.onkeydown=e=>{if(e.key==='ArrowRight')go(1);if(e.key==='ArrowLeft')go(-1)};
if(D.steps.length)draw();else $('msg').textContent=D.error?D.error.message:'';
</script></body></html>"""
