"""LR(0) items, CLOSURE, GOTO and the canonical collection (the DFA)."""

# An item is a pair (production_index, dot_position).


def closure(g, items):
    result = set(items)
    work = list(items)
    while work:
        p, d = work.pop()
        rhs = g.productions[p].rhs
        if d < len(rhs) and rhs[d] in g.nt_set:
            for q in g.by_lhs[rhs[d]]:
                it = (q.index, 0)
                if it not in result:
                    result.add(it)
                    work.append(it)
    return frozenset(result)


def goto(g, items, symbol):
    moved = {(p, d + 1) for p, d in items
             if d < len(g.productions[p].rhs) and g.productions[p].rhs[d] == symbol}
    return closure(g, moved) if moved else frozenset()


class Automaton:
    """states[i] = item set of I_i; transitions[(i, X)] = j."""

    def __init__(self, g):
        self.g = g
        start = closure(g, {(0, 0)})
        self.states = [start]
        self.transitions = {}
        index = {start: 0}
        i = 0
        while i < len(self.states):
            items = self.states[i]
            seen = []
            for p, d in sorted(items):
                rhs = g.productions[p].rhs
                if d < len(rhs) and rhs[d] not in seen:
                    seen.append(rhs[d])
            for x in seen:
                target = goto(g, items, x)
                if target not in index:
                    index[target] = len(self.states)
                    self.states.append(target)
                self.transitions[(i, x)] = index[target]
            i += 1

    def kernel(self, i):
        return frozenset(it for it in self.states[i] if it[1] > 0 or it[0] == 0)
