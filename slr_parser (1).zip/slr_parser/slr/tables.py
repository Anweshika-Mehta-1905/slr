"""Algorithmic construction of the SLR(1) ACTION/GOTO tables with conflict detection."""
from .grammar import END


def act_str(a):
    return "acc" if a[0] == "acc" else f"{a[0]}{a[1]}"


class Conflict:
    def __init__(self, state, symbol, actions):
        self.state, self.symbol, self.actions = state, symbol, actions
        kinds = {a[0] for a in actions}
        self.kind = "shift/reduce" if "s" in kinds else "reduce/reduce"

    def describe(self, g):
        parts = []
        for a in self.actions:
            if a[0] == "s":
                parts.append(f"shift to I{a[1]}")
            elif a[0] == "r":
                parts.append(f"reduce by [{a[1]}] {g.productions[a[1]]}")
            else:
                parts.append("accept")
        return (f"{self.kind} conflict in I{self.state} on '{self.symbol}': "
                + "  vs  ".join(parts))


class SLRTable:
    """action[state][terminal] -> list of actions (more than one entry = conflict)."""

    def __init__(self, g, automaton):
        self.g, self.automaton = g, automaton
        n = len(automaton.states)
        self.action = {i: {} for i in range(n)}
        self.goto = {i: {} for i in range(n)}
        self.conflicts = []

        def add(i, a, act):
            cell = self.action[i].setdefault(a, [])
            if act not in cell:
                cell.append(act)

        for i, items in enumerate(automaton.states):
            for p, d in sorted(items):
                prod = g.productions[p]
                if d < len(prod.rhs):
                    x = prod.rhs[d]
                    j = automaton.transitions[(i, x)]
                    if x in g.nt_set:
                        self.goto[i][x] = j
                    else:
                        add(i, x, ("s", j))
                elif p == 0:                       # S' -> S .
                    add(i, END, ("acc",))
                else:                              # A -> alpha .   reduce on FOLLOW(A)
                    for a in g.follow[prod.lhs]:
                        add(i, a, ("r", p))

        order = {"s": 0, "r": 1, "acc": 2}
        for i in range(n):
            for a, cell in self.action[i].items():
                cell.sort(key=lambda x: (order[x[0]], x[1] if len(x) > 1 else 0))
                if len(cell) > 1:
                    self.conflicts.append(Conflict(i, a, list(cell)))
        self.conflicts.sort(key=lambda c: (c.state, c.symbol))

    @property
    def is_slr1(self):
        return not self.conflicts

    def cell_str(self, i, sym):
        cell = self.action[i].get(sym)
        return "/".join(act_str(a) for a in cell) if cell else ""
