"""Grammar-driven tokenizer: keywords/operators are taken from the grammar's terminals."""
import re
from collections import namedtuple

Token = namedtuple("Token", "type text line col")
_WORD = re.compile(r"[A-Za-z_]\w*")
_NUM = re.compile(r"\d+")


class LexError(Exception):
    def __init__(self, msg, line, col):
        super().__init__(msg)
        self.msg, self.line, self.col = msg, line, col


class Lexer:
    def __init__(self, g):
        terms = set(g.terminals)
        self.keywords = {t for t in terms if _WORD.fullmatch(t) and t not in ("id", "num")}
        self.ops = sorted((t for t in terms if not re.fullmatch(r"\w+", t)),
                          key=len, reverse=True)           # longest match first
        self.has_id, self.has_num = "id" in terms, "num" in terms

    def tokenize(self, src):
        out, i, line, col = [], 0, 1, 1
        while i < len(src):
            c = src[i]
            if c == "\n":
                i, line, col = i + 1, line + 1, 1
                continue
            if c.isspace():
                i, col = i + 1, col + 1
                continue
            if c.isalpha() or c == "_":
                text = _WORD.match(src, i).group()
                if text in self.keywords:
                    ttype = text
                elif self.has_id:
                    ttype = "id"
                else:
                    raise LexError(f"unknown word '{text}'", line, col)
            elif c.isdigit():
                text = _NUM.match(src, i).group()
                if not self.has_num:
                    raise LexError(f"unexpected number '{text}'", line, col)
                ttype = "num"
            else:
                for op in self.ops:
                    if src.startswith(op, i):
                        text, ttype = op, op
                        break
                else:
                    raise LexError(f"unrecognised character '{c}'", line, col)
            out.append(Token(ttype, text, line, col))
            i, col = i + len(text), col + len(text)
        out.append(Token("$", "$", line, col))
        return out
