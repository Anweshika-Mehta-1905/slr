"""Table-driven shift-reduce parser with a step trace and expected-token errors."""
from dataclasses import dataclass, field
from .grammar import END
from .lexer import LexError

PRETTY = {"id": "identifier", "num": "number", "$": "end of input"}


def pretty(sym):
    return PRETTY.get(sym, f"'{sym}'")


@dataclass
class Step:
    n: int
    states: list
    symbols: list
    remaining: list
    action: str
    kind: str                       # shift | reduce | accept | error
    prod: int = None                # production index for reduce
    popped: list = field(default_factory=list)

    def stack_str(self):
        parts = [str(self.states[0])]
        for sym, st in zip(self.symbols, self.states[1:]):
            parts += [sym, str(st)]
        return " ".join(parts)

    def remaining_str(self):
        return " ".join(self.remaining)


@dataclass
class ParseError:
    kind: str                       # syntax | lexical | limit
    message: str
    line: int = None
    col: int = None
    token: object = None
    expected: list = field(default_factory=list)       # verified expected tokens
    expected_raw: list = field(default_factory=list)   # every non-blank ACTION entry


@dataclass
class ParseResult:
    accepted: bool
    steps: list
    error: ParseError = None
    reductions: list = field(default_factory=list)     # production indices, in order
    tokens: list = field(default_factory=list)


def _viable(states, t, table, g):
    """Would lookahead t eventually be shifted/accepted? (dry run on a copy of the stack)"""
    st = list(states)
    for _ in range(1000):
        cell = table.action[st[-1]].get(t)
        if not cell:
            return False
        a = cell[0]
        if a[0] in ("s", "acc"):
            return True
        p = g.productions[a[1]]
        if p.rhs:
            del st[-len(p.rhs):]
        nxt = table.goto[st[-1]].get(p.lhs)
        if nxt is None:
            return False
        st.append(nxt)
    return False


def expected_tokens(states, table, g):
    """NOVELTY: SLR reduces on every FOLLOW token, so the raw ACTION row over-reports.
    We keep only tokens whose dry-run reaches a shift/accept."""
    raw = [t for t in g.terminals + [END] if t in table.action[states[-1]]]
    good = [t for t in raw if _viable(states, t, table, g)]
    return good or raw, raw


def parse(tokens, g, table, max_steps=10000):
    if table.conflicts:
        raise ValueError("ACTION table has conflicts; this grammar is not SLR(1) "
                         "and the parser refuses to guess.")
    states, symbols, pos = [0], [], 0
    steps, reductions = [], []
    while True:
        if len(steps) >= max_steps:
            err = ParseError("limit", f"step limit ({max_steps}) exceeded - possible infinite loop")
            return ParseResult(False, steps, err, reductions, tokens)
        tok = tokens[pos]
        base = dict(n=len(steps) + 1, states=list(states), symbols=list(symbols),
                    remaining=[t.type for t in tokens[pos:]])
        cell = table.action[states[-1]].get(tok.type)
        if not cell:
            expected, raw = expected_tokens(states, table, g)
            unexp = "end of input" if tok.type == END else f"'{tok.text}'"
            msg = (f"Syntax error at line {tok.line}, column {tok.col}: unexpected {unexp}; "
                   f"expected {', '.join(pretty(t) for t in expected)}")
            steps.append(Step(action=f"ERROR: unexpected {unexp}", kind="error", **base))
            return ParseResult(False, steps, ParseError("syntax", msg, tok.line, tok.col,
                                                        tok, expected, raw), reductions, tokens)
        act = cell[0]
        if act[0] == "s":
            steps.append(Step(action=f"Shift {act[1]}", kind="shift", **base))
            symbols.append(tok.type)
            states.append(act[1])
            pos += 1
        elif act[0] == "r":
            p = g.productions[act[1]]
            k = len(p.rhs)
            popped = symbols[len(symbols) - k:] if k else []
            steps.append(Step(action=f"Reduce {p}", kind="reduce", prod=p.index,
                              popped=list(popped), **base))
            if k:
                del symbols[-k:]
                del states[-k:]
            symbols.append(p.lhs)
            states.append(table.goto[states[-1]][p.lhs])
            reductions.append(p.index)
        else:
            steps.append(Step(action="Accept", kind="accept", **base))
            return ParseResult(True, steps, None, reductions, tokens)


def parse_source(src, g, table, lexer, max_steps=10000):
    try:
        tokens = lexer.tokenize(src)
    except LexError as e:
        err = ParseError("lexical", f"Lexical error at line {e.line}, column {e.col}: {e.msg}",
                         e.line, e.col)
        return ParseResult(False, [], err, [], [])
    return parse(tokens, g, table, max_steps)
