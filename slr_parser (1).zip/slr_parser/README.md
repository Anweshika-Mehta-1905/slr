# SLR(1) Parser for MiniLang

Pure Python 3.8+ (standard library only; Graphviz and a browser are optional for viewing).

```
python main.py --show all                          # grammar, FIRST/FOLLOW, items, transitions, table, conflicts
python main.py --parse "let x = 1 + 2 ;" --trace  # step-by-step trace
python main.py --file examples/valid_3.src --html trace.html   # interactive viewer
python main.py --dot automaton.dot && dot -Tpng automaton.dot -o automaton.png
python main.py --demo                              # all examples/*.src
python main.py --grammar grammars/not_slr.grammar --show conflicts
python -m unittest discover -s tests -v            # 36 tests
```
Exit codes: 0 accepted, 1 rejected, 2 grammar problem or conflicts (parsing refused).
Grammar file syntax: `A -> x B | ε`, one symbol per whitespace-separated word, `#` starts a comment.
